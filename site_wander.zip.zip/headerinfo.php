<div class="header">
<div class="d-flex flex-column justify-content-end text-dark flex-wrap bg-dark px-5 text-white" style="height: 100%; opacity: .8">
        
  <h1>Fundamentos de PHP</h1>
  <p>Prof. Wanderlei Silva do Carmo <wander.silva@gmail.com></p>
  <div id="relogio"></div>

</div>
</div>
