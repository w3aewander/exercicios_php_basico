<div class="nav bg-primary text-white">
    <div class="p-5 mx-auto text-center">

             Professor Wanderlei Silva do Carmo <wander.silva@gmail.com><br>
             <?="Copyleft @" . date('Y');?>

 
    </div>
  
</div>

<script src="./js/fontawesome.min.js"></script>
<script src="./js/bootstrap.min.js"></script>
<script src="./js/app.js"></script>

</body>
</html>